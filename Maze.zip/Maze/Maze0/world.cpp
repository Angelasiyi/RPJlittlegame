#include "world.h"
#include <fstream>
#include <iostream>
using namespace std;

int World::hurtlevel=-1;//怪兽的伤害点数
int World::curelevel=1;//补给品的补血点数

void World::initWorld(const char *mapFile){

    this->_player.initObj("player");
    this->_player.setPosX(5);
    this->_player.setPosY(5);

    ifstream fin(mapFile);
    if(!fin){
        cout<<"error open!!"<<endl;
        return;
    }
    else{
        int x,y;
        string name;
        while(fin>>name>>x>>y){
            //cout<<name<<endl;
            if(name=="wall1"||name=="wall2"||name=="wall3"||name=="wall4"){
                Wall wall;
                wall.initObj(name);
                wall.setPosX(x);
                wall.setPosY(y);
                this->_walls.push_back(wall);
            }
            else if(name=="Kiki"||name=="Minho"||name=="Terasa"||name=="Newt"){
                Ally ally;
                ally.initObj(name);
                ally.setPosX(x);
                ally.setPosY(y);
                this->_allys.push_back(ally);
            }
            else if(name=="spider")
            {
                this->_spider.initObj(name);
                this->_spider.setPosX(x);
                this->_spider.setPosY(y);

            }
            /*else if(name=="bullet")
            {
                Bullet bullets;
                bullets.initObj(name);
                bullets.setPosX(x);
                bullets.setPosY(y);
                this->_bullets.push_back(bullets);
            }*/
            else{
                RPGObj obj;
                obj.initObj(name);
                obj.setPosX(x);
                obj.setPosY(y);
                this->_objs.push_back(obj);
            }
        }
    }
    fin.close();
}

void World::showworld(QPainter * painter){
    vector<RPGObj>::iterator it1;
    for(it1=this->_objs.begin();it1!=this->_objs.end();it1++){
        (*it1).show(painter);
    }
    vector<Wall>::iterator it2;
    for(it2=this->_walls.begin();it2!=this->_walls.end();it2++){
        (*it2).show(painter);
    }
    vector<Ally>::iterator it3;
    for(it3=this->_allys.begin();it3!=this->_allys.end();it3++){
        (*it3).show(painter);
    }
    /*vector<Bullet>::iterator it4;
    for(it4=this->_allys.begin();it4!=this->_allys.end();it4++)
    {
        if(!(*it4).getifDisappear)
        {
            (*it4).show(painter);
        }
    }*/
    this->_monster.show(painter);
    this->_spider.show(painter);


    if(_player.getHP()>0) this->_player.show(painter);

    else {
        if(_player.getHP()==0) cout<<"GAME OVER!!!"<<endl;
        _player.updateHP(-1);
    }

}

bool World::handlePlayerlive(){
    if(_player.getHP()<=0) return false;
    else return true;
}
void World::handlePlayerMove(int direction, int steps){
    //direction =1,2,3,4 for 上下左右
    if(handlePlayerlive()==false) return;
    vector<RPGObj>::iterator it;
    int px=_player.getPosX();
    int py=_player.getPosY();
    if(direction==1){
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
            if(px-(*it).getPosX()<(*it).getWidth()&&px>=(*it).getPosX()&&(*it).getPosY()+(*it).getHeight()-1==py){
                if((*it).canCover()==true){
                    this->_player.move(direction, steps);
                }
                if((*it).canEat()==true){
                    it=_objs.erase(it);
                    _player.updateHP(curelevel);//吃东西后HP变高，可自定义不同东西的HP增长值
                    cout<<"ummm..delicious!HP++!!Your HP:"<<_player.getHP()<<endl;
                }
            return;
            }
        }
        if((px-_monster.getPosX()<_monster.getWidth()&&px>=_monster.getPosX()&&_monster.getPosY()+_monster.getHeight()-1==py)) {
            _player.updateHP(hurtlevel);//被打后HP下降，可自定义不同怪兽攻击值
            cout<<"Dagerous!!!HP--!!Your HP:"<<_player.getHP()<<endl;
            return;
        }
    }
    else if(direction==2){
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
            if(px-(*it).getPosX()<(*it).getWidth()&&px>=(*it).getPosX()&&(*it).getPosY()-2==py){
                if((*it).canCover()==true){
                    this->_player.move(direction, steps);
                }
                if((*it).canEat()==true){
                    it=_objs.erase(it);
                    _player.updateHP(curelevel);
                    cout<<"ummm..delicious!HP++!!Your HP:"<<_player.getHP()<<endl;
                }
            return;
            }
        }
        if(px-_monster.getPosX()<_monster.getWidth()&&px>=_monster.getPosX()&&_monster.getPosY()-2==py) {
            _player.updateHP(hurtlevel);
            cout<<"Dagerous!!!HP--!!Your HP:"<<_player.getHP()<<endl;
            return;
        }
    }
    else if(direction==3){
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
            if((*it).getPosX()+(*it).getWidth()==px&&(*it).getPosY()-1<=py&&(*it).getPosY()+(*it).getHeight()-1>py){
                if((*it).canCover()==true){
                    this->_player.move(direction, steps);
                }
                if((*it).canEat()==true){
                    it=_objs.erase(it);
                    _player.updateHP(curelevel);
                    cout<<"ummm..delicious!HP++!!Your HP:"<<_player.getHP()<<endl;
                }
            return;
            }
        }
        if(_monster.getPosX()+_monster.getWidth()==px&&_monster.getPosY()-1<=py&&_monster.getPosY()+_monster.getHeight()-1>py) {
            _player.updateHP(hurtlevel);
            cout<<"Dagerous!!!HP--!!Your HP:"<<_player.getHP()<<endl;
            return;
        }
    }
    else if(direction==4){
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
            if((*it).getPosX()-1==px&&(*it).getPosY()-1<=py&&(*it).getPosY()+(*it).getHeight()-1>py){
                if((*it).canCover()==true){
                    this->_player.move(direction, steps);
                }
                if((*it).canEat()==true){
                    it=_objs.erase(it);
                    _player.updateHP(curelevel);
                    cout<<"ummm..delicious!HP++!!Your HP:"<<_player.getHP()<<endl;
                }
            return;
            }
        }
        if(_monster.getPosX()-1==px&&_monster.getPosY()-1<=py&&_monster.getPosY()+_monster.getHeight()-1>py) {
            _player.updateHP(hurtlevel);
            cout<<"Dagerous!!!HP--!!Your HP:"<<_player.getHP()<<endl;
            return;
        }
    }
    this->_player.move(direction, steps);
}

void World::handleMonsterMove(int direction, int steps){
    //direction =1,2,3,4 for 上下左右
    if(handlePlayerlive()==false) return;
    vector<RPGObj>::iterator it;
    int px=_monster.getPosX();
    int py=_monster.getPosY();
    if(direction==1){
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
            if(px-(*it).getPosX()<(*it).getWidth()&&px>=(*it).getPosX()&&(*it).getPosY()+(*it).getHeight()-1==py){
                if((*it).canCover()==true){
                    this->_monster.move(direction, steps);
                }
            return;
            }
        }
        if(px-_player.getPosX()<_player.getWidth()&&px>=_player.getPosX()&&_player.getPosY()+_player.getHeight()-1==py){
            _player.updateHP(hurtlevel);
            cout<<"Dagerous!!!HP--!!Your HP:"<<_player.getHP()<<endl;
            return;
        }
    }
    else if(direction==2){
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
            if(px-(*it).getPosX()<(*it).getWidth()&&px>=(*it).getPosX()&&(*it).getPosY()-2==py){
                if((*it).canCover()==true){
                    this->_monster.move(direction, steps);
                }
            return;
            }
        }
        if(px-_player.getPosX()<_player.getWidth()&&px>=_player.getPosX()&&_player.getPosY()-2==py){
            _player.updateHP(hurtlevel);
            cout<<"Dagerous!!!HP--!!Your HP:"<<_player.getHP()<<endl;
            return;
        }
    }
    else if(direction==3){
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
            if((*it).getPosX()+(*it).getWidth()==px&&(*it).getPosY()-1<=py&&(*it).getPosY()+(*it).getHeight()-1>py){
                if((*it).canCover()==true){
                    this->_monster.move(direction, steps);
                }
            return;
            }
        }
        if(_player.getPosX()+_player.getWidth()==px&&_player.getPosY()-1<=py&&_player.getPosY()+_player.getHeight()-1>py){
            _player.updateHP(hurtlevel);
            cout<<"Dagerous!!!HP--!!Your HP:"<<_player.getHP()<<endl;
            return;
        }
    }
    else if(direction==4){
        for(it=this->_objs.begin();it!=this->_objs.end();it++){
            if((*it).getPosX()-1==px&&(*it).getPosY()-1<=py&&(*it).getPosY()+(*it).getHeight()-1>py){
                if((*it).canCover()==true){
                    this->_monster.move(direction, steps);
                }
            return;
            }
        }
        if(_player.getPosX()-1==px&&_player.getPosY()-1<=py&&_player.getPosY()+_player.getHeight()-1>py){
            _player.updateHP(hurtlevel);
            cout<<"Dagerous!!!HP--!!Your HP:"<<_player.getHP()<<endl;
            return;
        }
    }
    this->_monster.move(direction, steps);
}
void World::handleWallMove(int direction, int steps){
    vector<Wall>::iterator it;
    int px;
    int py;
    for(it=this->_walls.begin();it!=this->_walls.end();it++){
        px=(*it).getPosX();
        py=(*it).getPosY();
        (*it).move(direction, steps);
    }
}

/*void World::createThing(int x,int y){
    vector<RPGObj>::iterator it;
    string s;
    for(it=this->_objs.begin();it!=this->_objs.end();it++){
        if((*it).getPosX()==x&&(*it).getPosY()==y) return;
    }
    int d = rand()%2;
    if(d==0){
        s="stone";
    }
    else s="fruit";
    RPGObj obj;
    obj.initObj(s);
    obj.setPosX(x);
    obj.setPosY(y);
    this->_objs.push_back(obj);
}
*/

