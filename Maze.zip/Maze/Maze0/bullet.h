#ifndef BULLET_H
#define BULLET_H
#include "rpgobj.h"
#include <iostream>

class Bullet: public RPGObj
{
public:
    Bullet(){canExplode=1;ifDisappear=0;}
    ~Bullet(){}

    bool getcanExplode(){return canExplode;}
    bool getifDisappear(){return ifDisappear;}
    void setifDisappear(bool a){ifDisappear=a;}
    void move(int direction);//子弹只能平动或者竖直移动 不需要steps只要规定子弹遇障碍物停止

    //friend void ifSuccesss(vector<RPGObj>_Obj,Monster _mons,Player _pls);//判断是否与物体相撞 相撞ifdisappear=0
    //void initObj(string type);
    //void show(QPainter *painter);
    //void explode();//子弹爆炸


//子弹如何实现平动？？爆炸如何表现？？
protected:
    bool canExplode;
    bool ifDisappear;

};

#endif // BULLET_H
