#ifndef LOAD_H
#define LOAD_H
#include <iostream>
#include <fstream>

class Load
{
public:
    Load(){}
    ~Load(){}
    void Save(const char* filename);//存档
    int Read(const char* filename);//读档
};

#endif // LOAD_H
