#include "mw2.h"
#include "ui_mw2.h"
#include "icon.h"
#include <fstream>
#include <map>
#include <iostream>

using namespace std;

MW2::MW2(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MW2)
{
    ui->setupUi(this);
    //init game world
    initWorld("D:/QTtasks/maze_map(2).txt");//TODO 应该是输入有效的地图文件

    //以下是对时钟的初始化
    timer1 = new QTimer(this);
    connect(timer1,SIGNAL(timeout()),this,SLOT(randomMove()));//timeoutslot()为自定义槽
        //时钟事件与randomMove函数绑定
    timer1->start(100);
    timer1->setInterval(500);

    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
        //设置随机数种子

    /*timer2 = new QTimer(this);
    connect(timer2,SIGNAL(timeout()),this,SLOT(randomCreate()));//timeoutslot()为自定义槽
        //时钟事件与randomMove函数绑定
    timer2->start(100);
    timer2->setInterval(1000);*/

    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));

    this->MonsterShot=0;//用于判断Monster被命中次数
}

MW2::~MW2()
{
    delete ui;
}
void MW2::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix;
    pix.load("D:/QTtasks/images/background2.png");//TODO
    painter.drawPixmap(0,0,1200,750,pix);
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    this->showworld(pa);
    pa->end();
    delete pa;
}
void MW2::keyPressEvent(QKeyEvent *e)
{
    //direction = 1,2,3,4 for 上下左右
    if(e->key() == Qt::Key_A)
    {
        this->handlePlayerMove(3,1);
    }
    else if(e->key() == Qt::Key_D)
    {
        this->handlePlayerMove(4,1);
    }
    else if(e->key() == Qt::Key_W)
    {
        this->handlePlayerMove(1,1);
    }
    else if(e->key() == Qt::Key_S)
    {
         this->handlePlayerMove(2,1);
    }
    else if(e->key() == Qt::Key_E)
    {//不同技能Set
        if(this->MonsterShot>1&&this->MonsterShot<3)this->_player.Setbullet(2);
        else if (this->MonsterShot==1||this->MonsterShot==0)this->_player.Setbullet(1);
        else if(this->MonsterShot>=3&&this->MonsterShot%4!=0)this->_player.Setbullet(3);
        else if(this->MonsterShot>=3&&this->MonsterShot%4==0)this->_player.Setbullet(4);

        this->_player.DisappearBullet(0);
    }
    else if(e->key() == Qt::Key_Q)
    {
        this->handleBulletMove();
    }

    this->repaint();
}
void MW2::handleBulletMove()
{

    this->_player.Fire();
    int bx=this->_player.getBulletX();
    int by=this->_player.getBulletY();
    int sx=this->_spider.getPosX();
    int sy=this->_spider.getPosY();

    if(((bx-sx)<=this->_spider.getWidth()&&(bx>sx))&&((by-sy)<=this->_spider.getHeight()&&(by>sy)))
    {
        cout<<"HIT"<<endl;
        this->MonsterShot+=1;
        //实现技能
        if(this->MonsterShot>5&&this->MonsterShot<11)this->_spider.updateHP(-10);
        else if (this->MonsterShot==1)this->_spider.updateHP(-5);
        else if(this->MonsterShot>=11&&this->MonsterShot%3!=0)this->_spider.updateHP(-20);
        else if(this->MonsterShot>=11&&this->MonsterShot%3==0)this->_spider.SetcanFire(0);


        cout<<"Monster HP:"<<this->_spider.getHP()<<"/100"<<endl;
        this->_player.DisappearBullet(1);
    }


}
void MW2::handleBullet1Move(int dir)
{
    this->_spider.Fire(dir);
    int bx=this->_spider.getBulletX();
    int by=this->_spider.getBulletY();
    int px=this->_player.getPosX();
    int py=this->_player.getPosY();

    if(((bx-px)<=this->_player.getWidth()&&(bx>px))&&((by-py)<=this->_player.getHeight()&&(by>py)))
    {
        cout<<"HIT"<<endl;
        this->_player.updateHP(-10);
        this->_spider.DisappearBullet(1);
    }

}

void MW2::handleSpidermove(int direction, int steps){

    vector<RPGObj>::iterator ito;
    int px= this->_spider.getPosX();
    int py= this->_spider.getPosY();

    if(direction==1)
    {
        for(ito=this->_objs.begin();ito!=this->_objs.end();ito++)
        {
           if(px-(*ito).getPosX()<(*ito).getWidth()&&px>=(*ito).getPosX()&&(*ito).getPosY()+(*ito).getHeight()-1==py)
           {
               if((*ito).canCover()==true)
               {
                    this->_spider.move(direction, steps);
               }
               return;
           }
        }
       if(px-_player.getPosX()<_player.getWidth()&&px>=_player.getPosX()&&_player.getPosY()+_player.getHeight()-1==py)
       {
            _player.updateHP(hurtlevel);
            cout<<"Dagerous!!!HP--!!Your HP:"<<_player.getHP()<<endl;
            return;
       }
    }
    else if(direction==2){
         for(ito=this->_objs.begin();ito!=this->_objs.end();ito++){
             if(px-(*ito).getPosX()<(*ito).getWidth()&&px>=(*ito).getPosX()&&(*ito).getPosY()-2==py){
                 if((*ito).canCover()==true){
                     this->_spider.move(direction, steps);
                 }
             return;
             }
         }
         if(px-_player.getPosX()<_player.getWidth()&&px>=_player.getPosX()&&_player.getPosY()-2==py){
         _player.updateHP(hurtlevel);
         cout<<"Dagerous!!!HP--!!Your HP:"<<_player.getHP()<<endl;
         return;
        }
    }
    else if(direction==3){
        for(ito=this->_objs.begin();ito!=this->_objs.end();ito++){
           if((*ito).getPosX()+(*ito).getWidth()==px&&(*ito).getPosY()-1<=py&&(*ito).getPosY()+(*ito).getHeight()-1>py){
               if((*ito).canCover()==true){
                    this->_spider.move(direction, steps);
               }
            return;
            }
        }
            if(_player.getPosX()+_player.getWidth()==px&&_player.getPosY()-1<=py&&_player.getPosY()+_player.getHeight()-1>py){
                _player.updateHP(hurtlevel);
                cout<<"Dagerous!!!HP--!!Your HP:"<<_player.getHP()<<endl;
                return;
            }
        }
        else if(direction==4){
            for(ito=this->_objs.begin();ito!=this->_objs.end();ito++){
                if((*ito).getPosX()-1==px&&(*ito).getPosY()-1<=py&&(*ito).getPosY()+(*ito).getHeight()-1>py){
                    if((*ito).canCover()==true){
                        this->_spider.move(direction, steps);
                    }
                return;
                }
            }
            if(_player.getPosX()-1==px&&_player.getPosY()-1<=py&&_player.getPosY()+_player.getHeight()-1>py){
                _player.updateHP(hurtlevel);
                cout<<"Dagerous!!!HP--!!Your HP:"<<_player.getHP()<<endl;
                return;
            }
        }
        this->_spider.move(direction, steps);
    }



void MW2::randomMove(){
    int d = 1 + rand()%4;
    this->handleSpiderMove(d,1);
    this->_spider.Setbullet();
    this->_spider.Fire(d);

    this->repaint();
}
