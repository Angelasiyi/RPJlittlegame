#include "mw2.h"
#include "ui_mw2.h"
#include "icon.h"
#include <fstream>
#include <map>
#include <iostream>

using namespace std;

MW2::MW2(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MW2)
{
    ui->setupUi(this);
    //init game world
    initWorld("D:/QTtasks/maze_map(2).txt");//TODO 应该是输入有效的地图文件

}

MW2::~MW2()
{
    delete ui;
}
void MW2::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix;
    pix.load("D:/QTtasks/images/background1.png");//TODO
    painter.drawPixmap(0,0,1200,750,pix);
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    this->showworld(pa);
    pa->end();
    delete pa;
}
void MW2::keyPressEvent(QKeyEvent *e)
{
    //direction = 1,2,3,4 for 上下左右
    if(e->key() == Qt::Key_A)
    {
        this->handlePlayerMove(3,1);
    }
    else if(e->key() == Qt::Key_D)
    {
        this->handlePlayerMove(4,1);
    }
    else if(e->key() == Qt::Key_W)
    {
        this->handlePlayerMove(1,1);
    }
    else if(e->key() == Qt::Key_S)
    {
         this->handlePlayerMove(2,1);
    }
    else if(e->key() == Qt::Key_E)
    {
        this->handleBulletMove();
    }
    this->repaint();
}
void MW2::handleBulletMove()
{

    while(1)
    {
        this->_player.Fire();
        if(this->_player.getBulletX()==this->_spider.getPosX()&&this->_player.getBulletY()==this->_spider.getPosY())
        {
            cout<<"HIT"<<endl;
            break;
        }
       cout<<"help"<<endl;
       break;
    }
    cout<<"out"<<endl;
}
