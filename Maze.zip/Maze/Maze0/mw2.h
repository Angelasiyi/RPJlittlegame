#ifndef MW2_H
#define MW2_H

#include <QMainWindow>
#include <QPainter>
#include <QKeyEvent>
#include <QTime>
#include <QTimer>
#include "rpgobj.h"
#include "bullet.h"
#include "world.h"

namespace Ui {
class MW2;
}

class MW2 : public QMainWindow, public World
{
    Q_OBJECT

public:
    explicit MW2(QWidget *parent = 0);
    ~MW2();
    void paintEvent(QPaintEvent *);
    void keyPressEvent(QKeyEvent *e);

    void handleSpidermove(int direction, int steps);
    void handleBulletMove();
    void handleBullet1Move(int dir);

protected slots:
    void randomMove();//响应时钟事件的函数

private:
    Ui::MW2 *ui;
    QTimer *timer1;
    QTimer *timer2;
    int MonsterShot;

};

#endif // MW2_H
