#ifndef MONSTER_H
#define MONSTER_H
#include "wall.h"
#include "player.h"
#include "bullet.h"


class Monster: public Wall
{
public:
    Monster(int initialHP);
    Monster(){}
    ~Monster(){}
    int getHP() {return this->HP;}
    //int getBullets(){return this->_bulletsNum;}

    void updateHP(int num){this->HP+=num;}
    //void updateBullets(int num){this->_bulletsNum+=num;}

    //friend void ifSuccesss(vector<RPGObj>_Obj,Monster _mons,Player _pls);

private:
    int HP;//生命值
    //int _bulletsNum;
    //vector<Bullet>_bullets(_bulletsNum);

};

#endif // MONSTER_H
