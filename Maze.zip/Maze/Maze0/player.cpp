#include "player.h"
#include "iostream"
using namespace std;

Player::Player(){
    HP=20;
    _bulletsNum=10;
    canFire=1;
    dir=2;
}
void Player::initObj(string type){
    if(type=="player"){
        QImage all;
        this->_coverable = false;
        this->_eatable = false;
        this->_vulnerable=true;

        this->_icon = ICON::findICON(type);

        all.load("D:/QTtasks/images/Thomas4.png");
        this->_up = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("D:/QTtasks/images/Thomas1.png");
        this->_down = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("D:/QTtasks/images/Thomas2.png");
        this->_left = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("D:/QTtasks/images/Thomas3.png");
        this->_right = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));


    }
    else cout<<"cannot find player"<<endl;

}
void Player::Setbullet(int choice)
{
    if(this->canFire)
   {
        if(choice==1)_bullets.initObj("bullet1");
        else if(choice==2)_bullets.initObj("bullet2");
        else if(choice==3)_bullets.initObj("bullet3");
        else if(choice==4)_bullets.initObj("bullet4");

        switch(this->getDir())
        {

        case 2:
            _bullets.setPosX(this->getPosX());
            _bullets.setPosY(this->getPosY()+1);
           break;

        case 1:
            _bullets.setPosX(this->getPosX());
            _bullets.setPosY(this->getPosY()-1);
            break;

        case 3:
            _bullets.setPosX(this->getPosX()-1);
            _bullets.setPosY(this->getPosY()+1);
            break;

        case 4:
            _bullets.setPosX(this->getPosX()+1);
            _bullets.setPosY(this->getPosY()+1);
            break;
        }
    }
    else cout<<"unable to fire"<<endl;
}
void Player::Fire()
{
     this->_bullets.move(this->getDir());
}

int Player::getBulletX()
{
    return this->_bullets.getPosX();
}
int Player::getBulletY()
{
    return this->_bullets.getPosY();
}

