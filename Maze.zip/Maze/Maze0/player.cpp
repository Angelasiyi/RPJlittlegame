#include "player.h"
#include "iostream"
using namespace std;

int Player::dir=2;//初始时人面朝下

Player::Player(){
    HP=20;
    _bulletsNum=10;
    canFire=1;
}
void Player::initObj(string type){
    if(type=="player"){
        QImage all;
        this->_coverable = false;
        this->_eatable = false;
        this->_vulnerable=true;

        this->_icon = ICON::findICON(type);

        all.load("D:/QTtasks/images/Thomas4.png");
        this->_up = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("D:/QTtasks/images/Thomas1.png");
        this->_down = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("D:/QTtasks/images/Thomas2.png");
        this->_left = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("D:/QTtasks/images/Thomas3.png");
        this->_right = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));


    }
    else cout<<"cannot find player"<<endl;

}
void Player::Fire()
{
    if(this->canFire)
    {
        Bullet _bullet;
        _bullet.initObj("bullet");

        switch(this->getDir())
        {

        case 2:{
            cout<<getDir()<<endl;
            cout<<"getPox2"<<endl;
            _bullet.setPosX(this->getPosX());
            _bullet.setPosY(this->getPosY()+1);
            cout<<"bullet x:"<<_bullet.getPosX()<<" "<<"y:"<<_bullet.getPosY()<<endl;//Die不变
            break;}

        case 1:{
            cout<<"getPox1"<<endl;
            _bullet.setPosX(this->getPosX());
            _bullet.setPosY(this->getPosY()-1);
            break;}

        case 3:{
            cout<<"getPox3"<<endl;
            _bullet.setPosX(this->getPosX()-1);
            _bullet.setPosY(this->getPosY());
            break;}

        case 4:{
            cout<<"getPox4"<<endl;
            _bullet.setPosX(this->getPosX()+1);
            _bullet.setPosY(this->getPosY());
            break;}
        }
        this->_bullets.move(this->getDir());
    }
    else cout<<"unable to fire"<<endl;
}
int Player::getBulletX()
{
    return this->_bullets.getPosX();
}
int Player::getBulletY()
{
    return this->_bullets.getPosY();
}

