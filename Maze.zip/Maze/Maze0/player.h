#ifndef PLAYER_H
#define PLAYER_H
#include "ally.h"
#include "bullet.h"

class Player: public Ally
{
public:
    friend class World;

    Player();
    ~Player(){}
    int getDir(){return dir;}
    void setDir(int Ndir){dir=Ndir;}
    bool getcanFire(){return canFire;}
    int getBulletX();
    int getBulletY();
    void DisappearBullet(bool a){this->_bullets.setifDisappear(a);}
    void initObj(string type);

    void Fire();
    void Setbullet(int choice);


    friend void showworld(QPainter * painter);

protected:
    int _bulletsNum;
    bool canFire;//是否能开火
    Bullet _bullets;



    //friend void ifSuccesss(vector<RPGObj>_Obj);
};

#endif // PLAYER_H
