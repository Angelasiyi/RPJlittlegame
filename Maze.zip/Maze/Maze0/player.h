#ifndef PLAYER_H
#define PLAYER_H
#include "ally.h"
#include "bullet.h"

class Player: public Ally
{
public:
    Player();
    ~Player(){}
    int getDir(){return dir;}
    bool getcanFire(){return canFire;}
    int getBulletX();
    int getBulletY();
    void initObj(string type);

    void Fire();

protected:
    int static dir;//记录人的朝向
    int _bulletsNum;
    bool canFire;//是否能开火
    Bullet _bullets;

    //friend void ifSuccesss(vector<RPGObj>_Obj);
};

#endif // PLAYER_H
