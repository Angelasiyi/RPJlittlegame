#include <monster.h>
Monster::Monster(int initialHP){
    HP=initialHP;
}

void Monster::Fire(int dir)
{

     this->_bullets.move(dir);

}


int Monster::getBulletX()
{
    return this->_bullets.getPosX();
}
int Monster::getBulletY()
{
    return this->_bullets.getPosY();
}

void Monster::Setbullet()
{
    if(this->canFire)
    {
        _bullets.initObj("bullet1");
        this->_bullets.setPosX(this->getPosX()+3);
        this->_bullets.setPosY(this->getPosY()+3);
        //cout<<"bullet x:"<<_bullets.getPosX()<<" "<<"y:"<<_bullets.getPosY()<<endl;
    }
    else {
        cout<<"unable to fire"<<endl;
    }
}
