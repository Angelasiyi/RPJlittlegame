#include <monster.h>
Monster::Monster(int initialHP){
    HP=initialHP;
}

