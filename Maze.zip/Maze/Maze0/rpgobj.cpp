#include "rpgobj.h"
#include <iostream>

void RPGObj::initObj(string type)
{
    //TODO 所支持的对象类型应定义为枚举
    if(type.compare("spider")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("wall1")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("wall2")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("wall3")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("wall4")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("bullet1")==0)
    {

        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("bullet2")==0)
    {

        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("bullet3")==0)
    {

        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("bullet4")==0)
    {

        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("skull1")==0)
    {

        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("skull2")==0)
    {

        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else
    {
        //TODO 应由专门的错误日志文件记录
        cout<<"invalid ICON type."<<type<<endl;
        return;
    }

    this->_icon = ICON::findICON(type);
    QImage all;

    if(this->_icon.getTypeName()=="wall1")
    {
        all.load("D:/QTtasks/images/wall1.png");
    }
    else if(this->_icon.getTypeName()=="wall2")
    {
        all.load("D:/QTtasks/images/wall2.png");
    }
    else if(this->_icon.getTypeName()=="wall3")
    {
        all.load("D:/QTtasks/images/wall3.png");
    }
    else if(this->_icon.getTypeName()=="wall4")
    {
        all.load("D:/QTtasks/images/wall4.png");
    }
    else if(this->_icon.getTypeName()=="spider")
    {
        //cout<<"icon spider"<<endl;
        all.load("D:/QTtasks/images/spider1.png");
    }
    //Bullet类图片载入
    else if(this->_icon.getTypeName()=="bullet1")
    {
        //cout<<"inload"<<endl;
        all.load("D:/QTtasks/images/magic1_1.png");
    }
    else if(this->_icon.getTypeName()=="bullet2")
    {
        //cout<<"inload"<<endl;
        all.load("D:/QTtasks/images/magic0_1.png");
    }
    else if(this->_icon.getTypeName()=="bullet3")
    {
        //cout<<"inload"<<endl;
        all.load("D:/QTtasks/images/magic4_1.png");
    }
    else if(this->_icon.getTypeName()=="bullet4")
    {
        //cout<<"inload"<<endl;
        all.load("D:/QTtasks/images/magic5_1.png");
    }
    //MW2背景块载入
    else if(this->_icon.getTypeName()=="skull1")
    {
        //cout<<"inload"<<endl;
        all.load("D:/QTtasks/images/skull1.png");
    }
    else if(this->_icon.getTypeName()=="skull2")
    {
        //cout<<"inload"<<endl;
        all.load("D:/QTtasks/images/skull2.png");
    }


    this->_pic = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
}

void RPGObj::show(QPainter * pa){
    int gSize = ICON::GRID_SIZE;
    pa->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_pic);
}



