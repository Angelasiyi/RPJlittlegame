#ifndef WORLD_H
#define WORLD_H

#include "rpgobj.h"
#include <vector>
#include <string>
#include <QPainter>
#include "player.h"
#include "monster.h"
#include "ally.h"
#include "wall.h"
#include "bullet.h"

class World
{

public:
    World(){}
    ~World(){}
    void initWorld(const char *mapFile);
        //输入的文件中定义了初始状态下游戏世界有哪些对象，出生点在哪
        /*e.g.
           player5 5
           stone 3 3
           fruit 7 8
         */
    void showworld(QPainter * painter);
        //显示游戏世界所有对象
    void handlePlayerMove(int direction, int steps);
    bool handlePlayerlive();
        //假定只有一个玩家

    virtual void handleMonsterMove(int direction, int steps);
    virtual void handleWallMove(int direction, int steps);
    virtual void handleSpiderMove(int direction,int steps);
    //virtual void createThing(int x,int y);


protected:
    static int hurtlevel;//怪兽的伤害点数
    static int curelevel;//补给品的补血点数
    vector<RPGObj> _objs;
    vector<Wall> _walls;
    vector<Ally> _allys;
   // vector<Bullet>_bullets;
    Player _player;
    Monster _spider;
    Monster _monster;

};

#endif // WORLD_H
