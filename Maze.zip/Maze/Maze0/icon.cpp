#include "icon.h"
#include<iostream>
int ICON::GRID_SIZE = 32;//单位像素32

pair<string,ICON> pairArray[] =
{//1 正面 2 左侧面 3 右侧面 4 背面 像素800*1000 一个人物200*250
    make_pair("player",ICON("player", 0, 0, 2, 3)),

    make_pair("Kiki1",ICON("Kiki1", 0, 0, 2, 3)),
    make_pair("Kiki2",ICON("Kiki2", 0, 0, 2, 3)),
    make_pair("Kiki3",ICON("Kiki3", 0, 0, 2, 3)),
    make_pair("Kiki4",ICON("Kiki4", 0, 0, 2, 3)),

    make_pair("Newt1",ICON("Newt1", 0, 0, 2, 3)),
    make_pair("Newt2",ICON("Newt2", 0, 0, 2, 3)),
    make_pair("Newt3",ICON("Newt3", 0, 0, 2, 3)),
    make_pair("Newt4",ICON("Newt4", 0, 0, 2, 3)),

    make_pair("Teresa1",ICON("Teresa1",0,0, 4, 5)),
    make_pair("Teresa2",ICON("Teresa2",0,5, 4, 5)),
    make_pair("Teresa3",ICON("Teresa3",0,10,4, 5)),
    make_pair("Teresa4",ICON("Teresa4",0,15,4, 5)),

    make_pair("Minho1",ICON("Minho1",0,0, 4, 5)),
    make_pair("Minho2",ICON("Minho2",0,5, 4, 5)),
    make_pair("Minho3",ICON("Minho3",0,10,4, 5)),
    make_pair("Minho4",ICON("Minho4",0,15,4, 5)),

    make_pair("wall1",ICON("wall1",0, 0, 4, 1)),
    make_pair("wall2",ICON("wall2",0, 0, 2, 2)),
    make_pair("wall3",ICON("wall3",0, 0, 1, 2)),
    make_pair("wall4",ICON("wall4",0, 0, 1, 1)),

    make_pair("bullet",ICON("bullet",0 ,0, 1, 1)),
    make_pair("spider",ICON("spider",0, 0, 4, 2))

};

map<string,ICON> ICON::GAME_ICON_SET(pairArray,pairArray+sizeof(pairArray)/sizeof(pairArray[0]));


ICON::ICON(string name, int x, int y, int w, int h){
    this->typeName = name;
    this->srcX = x;
    this->srcY = y;
    this->width = w;
    this->height = h;
}

ICON ICON::findICON(string type){
    map<string,ICON>::iterator kv;
    kv = ICON::GAME_ICON_SET.find(type);
    if (kv==ICON::GAME_ICON_SET.end()){

       cout<<"Error: cannot find ICON"<<endl;
       return ICON();
    }
    else{
        return kv->second;
    }
}
