#include <QApplication>
#include <QPainter>
#include "mainmenu.h"
#include "mw1.h"
#include "mw2.h"
#include "grass.h"
#include "iostream"

using namespace std;
int main(int argc, char *argv[])
{
    QApplication a(argc,argv);
    //MainWindow w;//创建主界面
    mainmenu m;//创建对话框。
    MW1 mw1;
    MW2 mw2;
    grass s1;
    if(m.exec() == QDialog::Accepted){//当按钮“进入主界面”被按下则执行
        cout<<"inside m.exec()"<<endl;
        grass::step=1;
        s1.show();
        if(s1.exec() == QDialog::Accepted){
            cout<<"inside s1.exec"<<endl;
            grass::step=17;//正常从2开始，17开始时即跳过背景介绍
            while(grass::step<17){
                cout<<"inside while"<<endl;
                int rec=s1.exec();
                if(rec == QDialog::Rejected){
                    a.lastWindowClosed();
                    cout<<"s1.reject"<<endl;
                    return 0;
                }
                else if(rec == QDialog::Accepted) {//如果直接写exec()==Qdialog::Accepted,则默认打开了一次exec()
                   s1.repaint();
                   s1.show();
                   cout<<"s1.accept"<<endl;
                   cout<<grass::step<<endl;
                }
                grass::step++;
            }
            s1.close();
            //mw1.show();
            mw2.show();
            return a.exec();
        }

    }
    else return 0;//否则退出程序
}
