#include "bullet.h"

void Bullet::move(int direction)
{
    switch(direction){
             case 1://上
                 this->setPosY(this->getPosY()-1);
                 //cout<<"in move1"<<this->getPosX()<<" "<<this->getPosY();
                 break;
             case 2://下
                 this->setPosY(this->getPosY()+1);
                 //cout<<"in move2"<<this->getPosX()<<" "<<this->getPosY();
                 break;
             case 3://左
                 this->setPosX(this->getPosX()-1);
                 //cout<<"in move3"<<this->getPosX()<<" "<<this->getPosY();
                 break;
             case 4://右
                 this->setPosX(this->getPosX()+1);
                 //cout<<"in move4"<<this->getPosX()<<" "<<this->getPosY();
                 break;
           }
}


