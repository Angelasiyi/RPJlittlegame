#include "grass.h"
#include "ui_grass.h"
#include <QPainter>
#include <iostream>
using namespace std;
int grass::step=0;
grass::grass(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::grass)
{
    ui->setupUi(this);
}

grass::~grass()
{
    delete ui;
}

void grass::paintEvent(QPaintEvent *) {
    QPainter painter(this);
    QPixmap pix,Thomas,Minho;
    if(grass::step==1) {
        pix.load("D:/QTtasks/images/grass.jpg");
        Thomas.load("D:/QTtasks/images/p.png");
        painter.drawPixmap(0,0,1200,750,pix);
        painter.drawPixmap(0,150,525,840,Thomas);
    }
    else if(grass::step==2){
        pix.load("D:/QTtasks/images/s1.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==3){
        pix.load("D:/QTtasks/images/s2.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==4){
        pix.load("D:/QTtasks/images/s3.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==5){
        Minho.load("D:/QTtasks/images/M2.png");
        pix.load("D:/QTtasks/images/grass.jpg");
        Thomas.load("D:/QTtasks/images/p.png");
        painter.drawPixmap(0,0,1200,750,pix);
        painter.drawPixmap(0,150,525,840,Thomas);
        painter.drawPixmap(525,150,300,600,Minho);
    }
    else if(grass::step==6){
        pix.load("D:/QTtasks/images/s4.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==7){
        pix.load("D:/QTtasks/images/s5.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==8){
        pix.load("D:/QTtasks/images/s6.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==9){
        pix.load("D:/QTtasks/images/s7.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==10){
        pix.load("D:/QTtasks/images/s8.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==11){
        pix.load("D:/QTtasks/images/enter.jpg");
        Minho.load("D:/QTtasks/images/M2.png");
        Thomas.load("D:/QTtasks/images/p.png");
        painter.drawPixmap(0,0,1200,750,pix);
        painter.drawPixmap(0,150,525,840,Thomas);
        painter.drawPixmap(525,150,300,600,Minho);
    }
    else if(grass::step==12){
        pix.load("D:/QTtasks/images/s9.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==13){
        pix.load("D:/QTtasks/images/s10.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==14){
        pix.load("D:/QTtasks/images/s11.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==15){
        pix.load("D:/QTtasks/images/s12.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==16){
        pix.load("D:/QTtasks/images/s13.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    //cout<<grass::step<<endl;
}
void grass::on_pushButton_clicked()
{
    accept();//点击next
    cout<<"send accept"<<endl;
}

void grass::on_pushButton_2_clicked()
{
    reject();//点击close
    cout<<"send reject"<<endl;
}
