#include "ally.h"
#include "iostream"
using namespace std;

void Ally::move(int direction, int steps){
    switch (direction){
        case 1:
            this->_pos_y -= steps;
            dir=1;
            break;
        case 2:
            this->_pos_y += steps;
            dir=2;
            break;
        case 3:
            this->_pos_x -= steps;
            dir=3;
            break;
        case 4:
            this->_pos_x += steps;
            dir=4;
            break;
    }
}
void Ally::show(QPainter * painter){
    int gSize = ICON::GRID_SIZE;
    if(dir==1) painter->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_up);
    else if(dir==2) painter->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_down);
    else if(dir==3) painter->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_left);
    else painter->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_right);
}
void Ally::initObj(string type){
    QImage all;
    this->_icon = ICON::findICON(type);
    if(type=="Kiki"){
        this->_coverable = false;
        this->_eatable = false;
        this->_vulnerable=true;

        all.load("E:/images/Kiki4.png");
        this->_up = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("E:/images/Kiki1.png");
        this->_down = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("E:/images/Kiki2.png");
        this->_left = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("E:/images/Kiki3.png");
        this->_right = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
    }
    else if(type=="Terasa"){
        this->_coverable = false;
        this->_eatable = false;
        this->_vulnerable=true;

        all.load("E:/images/Terasa4.png");
        this->_up = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("E:/images/Terasa1.png");
        this->_down = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("E:/images/Terasa2.png");
        this->_left = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("E:/images/Terasa3.png");
        this->_right = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
    }
    else if(type=="Newt"){
        this->_coverable = false;
        this->_eatable = false;
        this->_vulnerable=true;

        all.load("E:/images/Newt4.png");
        this->_up = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("E:/images/Newt1.png");
        this->_down = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("E:/images/Newt2.png");
        this->_left = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("E:/images/Newt3.png");
        this->_right = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
    }
    else if(type=="Minho"){
        this->_coverable = false;
        this->_eatable = false;
        this->_vulnerable=true;

        all.load("E:/images/Minho4.png");
        this->_up = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("E:/images/Minho1.png");
        this->_down = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("E:/images/Minho2.png");
        this->_left = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("E:/images/Minho3.png");
        this->_right = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
    }
    else cout<<"cannot find this ally"<<endl;

}
