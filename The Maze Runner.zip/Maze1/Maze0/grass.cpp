#include "grass.h"
#include "ui_grass.h"
#include <QPainter>
#include"iostream"
using namespace std;
int grass::step=0;
grass::grass(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::grass)
{
    ui->setupUi(this);
}

grass::~grass()
{
    delete ui;
}

void grass::paintEvent(QPaintEvent *) {
    QPainter painter(this);
    QPixmap pix,Thomas,Minho,dialog;
    if(grass::step==1) {
        pix.load("E:/images/grass.jpg");
        Thomas.load("E:/images/p.png");
        dialog.load("E:/images/dialog2.png");
        painter.drawPixmap(0,0,1200,750,pix);
        painter.drawPixmap(0,150,525,840,Thomas);
        painter.drawPixmap(300,150,400,300,dialog);
    }
    else if(grass::step==2){
        pix.load("E:/images/s1.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==3){
        pix.load("E:/images/s2.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==4){
        pix.load("E:/images/s3.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==5){
        Minho.load("E:/images/M2.png");
        pix.load("E:/images/grass.jpg");
        Thomas.load("E:/images/p.png");
        dialog.load("E:/images/dialog1.png");
        painter.drawPixmap(0,0,1200,750,pix);
        painter.drawPixmap(0,150,525,840,Thomas);
        painter.drawPixmap(525,150,300,600,Minho);
        painter.drawPixmap(280,20,400,300,dialog);
    }
    else if(grass::step==6){
        pix.load("E:/images/s4.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==7){
        pix.load("E:/images/s5.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==8){
        pix.load("E:/images/s6.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==9){
        pix.load("E:/images/s7.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==10){
        pix.load("E:/images/s8.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==11){
        pix.load("E:/images/enter.jpg");
        Minho.load("E:/images/M2.png");
        Thomas.load("E:/images/p2.png");
        dialog.load("E:/images/dialog1.png");
        painter.drawPixmap(0,0,1200,750,pix);
        painter.drawPixmap(0,150,300,800,Thomas);
        painter.drawPixmap(525,150,300,600,Minho);
        painter.drawPixmap(280,20,400,300,dialog);
    }
    else if(grass::step==12){
        pix.load("E:/images/s9.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==13){
        pix.load("E:/images/s10.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==14){
        pix.load("E:/images/s11.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==15){
        pix.load("E:/images/s12.png");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==16){
        pix.load("E:/images/s13.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    else if(grass::step==17){
        pix.load("E:/images/s14.jpg");
        painter.drawPixmap(0,0,1200,750,pix);
    }
    //cout<<grass::step<<endl;
}
void grass::on_pushButton_clicked()
{
    accept();//点击next
}

void grass::on_pushButton_2_clicked()
{
    reject();//点击close
}
