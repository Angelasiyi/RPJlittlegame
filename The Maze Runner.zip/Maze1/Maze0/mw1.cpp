#include "mw1.h"
#include "ui_mw1.h"
#include "icon.h"
#include "load.h"
#include <QTimer>
#include <fstream>
#include <map>
#include <iostream>
using namespace std;

MW1::MW1(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MW1)
{
    ui->setupUi(this);
    //init game world
    initWorld("E:/mainmap.txt");

    QMediaPlayer * player = new QMediaPlayer;
    player->setMedia(QUrl::fromLocalFile("E:/images/backgroundmusic00.mp3"));
    player->setVolume(30);
    player->play();
}

MW1::~MW1()
{
    delete ui;
}

void MW1::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix;
    pix.load("E:/images/background1.png");
    painter.drawPixmap(0,0,1200,750,pix);
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    this->showworld(pa);
    pa->end();
    delete pa;
    chooselevel();
}

void MW1::keyPressEvent(QKeyEvent *e)
{
    //direction = 1,2,3,4 for 上下左右
    if(e->key() == Qt::Key_A)
    {
        this->handlePlayerMove(3,1);
    }
    else if(e->key() == Qt::Key_D)
    {
        this->handlePlayerMove(4,1);
    }
    else if(e->key() == Qt::Key_W)
    {
        this->handlePlayerMove(1,1);
    }
    else if(e->key() == Qt::Key_S)
    {
         this->handlePlayerMove(2,1);
    }
    //cout<<"player:"<<_player.getPosX()<<" "<<_player.getPosY()<<endl;
    this->repaint();
}

void MW1::chooselevel(){
    int i=0;
    for(i=0;i<_enters.size();i++){
        if(_enters[i].getPosX()==_player.getPosX()&&_enters[i].getPosY()==_player.getPosY()+2&&i<playerlevel){
            gamelevel=i+1;
            close();
        }
    }
}

void MW1::initWorld(const char *mapFile){

    this->_player.initObj("player");
    this->_player.setPosX(5);
    this->_player.setPosY(5);

    Load load;
    playerlevel=load.Read("E:/level.txt");

    ifstream fin(mapFile);
    if(!fin){
        cout<<"error open!!"<<endl;
        return;
    }
    else{
        int x,y;
        string name;
        while(fin>>name>>x>>y){
            //cout<<name<<endl;
            if(name=="wall1"||name=="wall2"||name=="wall3"||name=="wall4"){
                Wall wall;
                wall.initObj(name);
                wall.setPosX(x);
                wall.setPosY(y);
                this->_walls.push_back(wall);
            }
            else if(name=="enter")
            {
                RPGObj obj;
                obj.initObj(name);
                obj.setPosX(x);
                obj.setPosY(y);
                this->_enters.push_back(obj);
            }
            else{
                RPGObj obj;
                obj.initObj(name);
                obj.setPosX(x);
                obj.setPosY(y);
                this->_objs.push_back(obj);
            }
        }
    }
    fin.close();
}

void MW1::showworld(QPainter * painter){
    vector<RPGObj>::iterator it1;
    for(it1=this->_objs.begin();it1!=this->_objs.end();it1++){
        (*it1).show(painter);
    }

    vector<Wall>::iterator it2;
    for(it2=this->_walls.begin();it2!=this->_walls.end();it2++){
        (*it2).show(painter);
    }

    vector<RPGObj>::iterator it3;
    for(it3=this->_enters.begin();it3!=this->_enters.end();it3++){
        (*it3).show(painter);
    }
    this->_player.show(painter);
}

void MW1::on_pushButton_clicked()
{
    accept();
}
