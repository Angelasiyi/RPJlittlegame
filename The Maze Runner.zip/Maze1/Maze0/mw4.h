#ifndef MW4_H
#define MW4_H

#include <QDialog>
#include <QImage>
#include <QPainter>
#include "world.h"

namespace Ui {
class MW4;
}

class MW4 : public QDialog,public World
{
    Q_OBJECT

public:
    static int step;
    explicit MW4(QWidget *parent = 0);
    ~MW4();
    void paintEvent(QPaintEvent *);
private slots:
    void on_pushButton_clicked();

private:
    Ui::MW4 *ui;
};

#endif // MW4_H
