#include "mw4.h"
#include "ui_mw4.h"

int MW4::step=0;

MW4::MW4(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MW4)
{
    ui->setupUi(this);
    //init game world
    initWorld("E:/maze_map3.txt");
}

MW4::~MW4()
{
    delete ui;
}

void MW4::paintEvent(QPaintEvent *){
    if(step==1){
        QPainter painter(this);
        QPixmap pix;
        pix.load("E:/images/background1.png");
        painter.drawPixmap(0,0,500,750,pix);
        QPainter *pa;
        pa = new QPainter();
        pa->begin(this);
        this->showworld(pa);
        pa->end();
        delete pa;
    }
    else{
        QPainter painter(this);
        QPixmap pix;
        pix.load("E:/images/end.jpg");
        painter.drawPixmap(0,0,500,750,pix);
    }

}

void MW4::on_pushButton_clicked()
{
    accept();
}
