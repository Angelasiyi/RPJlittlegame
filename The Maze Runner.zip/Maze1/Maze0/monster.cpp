#include <monster.h>
Monster::Monster(int initialHP){
    HP=initialHP;
}

void Monster::Fire(int dir)
{

     this->_bullets.move(dir);

}

int Monster::getBulletX()
{
    return this->_bullets.getPosX();
}
int Monster::getBulletY()
{
    return this->_bullets.getPosY();
}


