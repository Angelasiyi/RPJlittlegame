#include "mw2.h"
#include "ui_mw2.h"
#include "icon.h"
#include "load.h"
#include <QTimer>
#include <fstream>
#include <map>
#include<QMessageBox>
#include <iostream>

using namespace std;

bool MW2::pass=false;//避免消息对话框递归重画

MW2::MW2(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MW2)
{
    ui->setupUi(this);
    initWorld("E:/maze_map2.txt");//TODO 应该是输入有效的地图文件

    this->MonsterShot=0;//用于判断Monster被命中次数

    QMediaPlayer * player = new QMediaPlayer;
    player->setMedia(QUrl::fromLocalFile("E:/images/backgroundmusic2.mp3"));
    player->setVolume(30);
    player->play();

    //控制怪兽移动，时钟事件与randomMove函数绑定
    timer1 = new QTimer(this);
    connect(timer1,SIGNAL(timeout()),this,SLOT(randomMove()));
    timer1->start(100);
    timer1->setInterval(500);
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));


    //控制产生补给,时钟事件与randomCreate函数绑定
    timer2 = new QTimer(this);
    connect(timer2,SIGNAL(timeout()),this,SLOT(randomCreate()));
    timer2->start(100);
    timer2->setInterval(1000);
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));

}

MW2::~MW2()
{
    delete ui;
}
void MW2::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix;
    pix.load("E:/images/background2.png");
    painter.drawPixmap(0,0,1220,750,pix);
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    this->showworld(pa);
    pa->end();
    delete pa;
    ispass();
}
void MW2::keyPressEvent(QKeyEvent *e)
{
    //direction = 1,2,3,4 for 上下左右
    if(e->key() == Qt::Key_A)
    {
        this->handlePlayerMove(3,1);
    }
    else if(e->key() == Qt::Key_D)
    {
        this->handlePlayerMove(4,1);
    }
    else if(e->key() == Qt::Key_W)
    {
        this->handlePlayerMove(1,1);
    }
    else if(e->key() == Qt::Key_S)
    {
         this->handlePlayerMove(2,1);
    }
    else if(e->key() == Qt::Key_E)
    {
        //不同技能Set
        if(_player.getATK()<=20)this->_player.Setbullet(1);
        else if (_player.getATK()>20&&_player.getATK()<=30)this->_player.Setbullet(2);
        else if(_player.getATK()>30&&_player.getATK()<=40)this->_player.Setbullet(3);
        else if(_player.getATK()>40&&_player.getATK()<=50)this->_player.Setbullet(4);

        this->_player.DisappearBullet(0);
    }
    else if(e->key() == Qt::Key_Q)
    {
        timer3 = new QTimer(this);
        connect(timer3,SIGNAL(timeout()),this,SLOT(handleBulletMove()));//timeoutslot()为自定义槽
        //时钟事件与randomMove函数绑定
        timer3->start(100);
        timer3->setInterval(200);
        qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
    }

    this->repaint();
}
void MW2::handleBulletMove()
{

    this->_player.Fire();
    int bx=this->_player.getBulletX();
    int by=this->_player.getBulletY();
    int sx=this->_spider.getPosX();
    int sy=this->_spider.getPosY();

    if(((bx-sx)<=this->_spider.getWidth()&&(bx>sx))&&((by-sy)<=this->_spider.getHeight()&&(by>sy)))
    {
        //cout<<"HIT"<<endl;
        QMediaPlayer * player = new QMediaPlayer;
        player->setMedia(QUrl::fromLocalFile("C:/Users/jmzxc/Desktop/images/hurt.mp3"));
        player->setVolume(20);
        player->play();
        //实现技能
        if(_player.getATK()<=20) this->_spider.updateHP(-2);
        else if (_player.getATK()>20&&_player.getATK()<=30)this->_spider.updateHP(-4);
        else if(_player.getATK()>30&&_player.getATK()<=40)this->_spider.updateHP(-6);
        else if(_player.getATK()>=40&&_player.getATK()<=50)this->_spider.SetcanFire(-8);

        cout<<"Monster HP:"<<this->_spider.getHP()<<"/100"<<endl;
        this->_player.DisappearBullet(1);
    }
}

void MW2::handleMonsterMove(int direction, int steps){
    vector<RPGObj>::iterator ito;
    int px= this->_spider.getPosX();
    int py= this->_spider.getPosY();

    if(direction==1)
    {
        for(ito=this->_objs.begin();ito!=this->_objs.end();ito++)
        {
           if(px-(*ito).getPosX()<(*ito).getWidth()&&px>=(*ito).getPosX()&&(*ito).getPosY()+(*ito).getHeight()-1==py)
           {
               if((*ito).canCover()==true)
               {
                    this->_spider.move(direction, steps);
               }
               return;
           }
        }
       if(px-_player.getPosX()<_player.getWidth()&&px>=_player.getPosX()&&_player.getPosY()+_player.getHeight()-1==py)
       {
            _player.updateHP(hurtlevel);
            cout<<"MW2:Dagerous!!!HP--!!Your HP:"<<_player.getHP()<<endl;
            return;
       }
    }
    else if(direction==2){
         for(ito=this->_objs.begin();ito!=this->_objs.end();ito++){
             if(px-(*ito).getPosX()<(*ito).getWidth()&&px>=(*ito).getPosX()&&(*ito).getPosY()-2==py){
                 if((*ito).canCover()==true){
                     this->_spider.move(direction, steps);
                 }
             return;
             }
         }
         if(px-_player.getPosX()<_player.getWidth()&&px>=_player.getPosX()&&_player.getPosY()-2==py){
         _player.updateHP(hurtlevel);
         cout<<"MW2:Dagerous!!!HP--!!Your HP:"<<_player.getHP()<<endl;
         return;
        }
    }
    else if(direction==3){
        for(ito=this->_objs.begin();ito!=this->_objs.end();ito++){
           if((*ito).getPosX()+(*ito).getWidth()==px&&(*ito).getPosY()-1<=py&&(*ito).getPosY()+(*ito).getHeight()-1>py){
               if((*ito).canCover()==true){
                    this->_spider.move(direction, steps);
               }
            return;
            }
        }
            if(_player.getPosX()+_player.getWidth()==px&&_player.getPosY()-1<=py&&_player.getPosY()+_player.getHeight()-1>py){
                _player.updateHP(hurtlevel);
                cout<<"MW2:Dagerous!!!HP--!!Your HP:"<<_player.getHP()<<endl;
                return;
            }
        }
        else if(direction==4){
            for(ito=this->_objs.begin();ito!=this->_objs.end();ito++){
                if((*ito).getPosX()-1==px&&(*ito).getPosY()-1<=py&&(*ito).getPosY()+(*ito).getHeight()-1>py){
                    if((*ito).canCover()==true){
                        this->_spider.move(direction, steps);
                    }
                return;
                }
            }
            if(_player.getPosX()-1==px&&_player.getPosY()-1<=py&&_player.getPosY()+_player.getHeight()-1>py){
                _player.updateHP(hurtlevel);
                cout<<"MW2:Dagerous!!!HP--!!Your HP:"<<_player.getHP()<<endl;
                return;
            }
        }
        this->_spider.move(direction, steps);
    }



void MW2::randomMove(){
    int d = 1 + rand()%4;
    if(this->_spider.getcanFire())
    {
        this->handleMonsterMove(d,1);
    }
    this->_fire1.initObj("fire1");
    this->_fire2.initObj("fire1");
    this->_fire3.initObj("fire1");
    this->_fire4.initObj("fire1");

    this->_fire1.setPosX(this->_spider.getPosX()-1);
    this->_fire1.setPosY(this->_spider.getPosY()+2);

    this->_fire2.setPosX(this->_spider.getPosX()+4);
    this->_fire2.setPosY(this->_spider.getPosY()+2);

    this->_fire3.setPosX(this->_spider.getPosX()+3);
    this->_fire3.setPosY(this->_spider.getPosY());

    this->_fire4.setPosX(this->_spider.getPosX());
    this->_fire4.setPosY(this->_spider.getPosY());


    this->_spider.Fire(d);

    this->repaint();
}

void MW2::ispass(){
    if(this->_spider.getHP()<0){
        QMediaPlayer * player = new QMediaPlayer;
        player->setMedia(QUrl::fromLocalFile("E:/images/MonsterDie.mp3"));
        player->setVolume(30);
        player->play();
        playerlevel=3;
        Load load;
        load.Save("E:/level.txt",playerlevel);
        if (pass==false){
            pass=true;
            QMessageBox::information(this, "Hint","YOU WIN!!!", QMessageBox::Ok);
            close();
        }

        close();
    }
}
void MW2::randomCreate(){
    int x = 2 + rand()%20;
    int y = 2 + (rand()*rand())%20;
    int n =rand()%5;
    string name;
    if(n==0) name="food1";
    else if(n==1) name="food2";
    else if(n==2) name="food3";
    else if(n==3) name="tool1";
    else if(n==4) name="tool2";

    RPGObj obj;
    obj.initObj(name);
    obj.setPosX(x);
    obj.setPosY(y);
    this->_objs.push_back(obj);
    this->repaint();
}
