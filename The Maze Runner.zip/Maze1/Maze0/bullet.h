#ifndef BULLET_H
#define BULLET_H
#include "rpgobj.h"
#include <iostream>

class Bullet: public RPGObj
{
public:
    Bullet(){canExplode=1;ifDisappear=0;}
    ~Bullet(){}

    bool getcanExplode(){return canExplode;}
    bool getifDisappear(){return ifDisappear;}
    void setifDisappear(bool a){ifDisappear=a;}
    void move(int direction);//子弹只能平动或者竖直移动 不需要steps只要规定子弹遇障碍物停止


protected:
    bool canExplode;
    bool ifDisappear;

};

#endif // BULLET_H
