#ifndef WALL_H
#define WALL_H
#include "rpgobj.h"

class Wall:public RPGObj
{
public:
    Wall(){}
    ~Wall(){}
    void move(int direction, int steps=1);
};

#endif // WALL_H
