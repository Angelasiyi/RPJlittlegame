#include "icon.h"
#include<iostream>
int ICON::GRID_SIZE = 32;//单位像素32

pair<string,ICON> pairArray[] =
{//1 正面 2 左侧面 3 右侧面 4 背面
    make_pair("player",ICON("player", 0, 0, 2, 3)),

    make_pair("Kiki",ICON("Kiki", 0, 0, 2, 3)),
    make_pair("Newt",ICON("Newt", 0, 0, 2, 3)),
    make_pair("Terasa",ICON("Terasa", 0, 0, 2, 3)),
    make_pair("Minho",ICON("Minho", 0, 0, 2, 3)),

    make_pair("wall1",ICON("wall1",0, 0, 4, 1)),
    make_pair("wall2",ICON("wall2",0, 0, 2, 2)),
    make_pair("wall3",ICON("wall3",0, 0, 1, 2)),
    make_pair("wall4",ICON("wall4",0, 0, 1, 1)),

    make_pair("bullet1",ICON("bullet1",0 ,0, 2, 2)),
    make_pair("bullet2",ICON("bullet2",0 ,0, 4, 2)),
    make_pair("bullet3",ICON("bullet3",0 ,0, 4, 2)),
    make_pair("bullet4",ICON("bullet4",0 ,0, 4, 2)),

    make_pair("spider",ICON("spider",0, 0, 4, 4)),

    make_pair("skull1",ICON("skull1",0, 0, 2, 2)),
    make_pair("skull2",ICON("skull2",0, 0, 2, 2)),

    make_pair("enter",ICON("enter",1, 0, 1, 1)),
    make_pair("final",ICON("final",1, 1, 1, 1)),

    make_pair("food1",ICON("food1",8, 3, 1, 1)),
    make_pair("food2",ICON("food2",9, 3, 1, 1)),
    make_pair("food3",ICON("food3",10, 3, 1, 1)),

    make_pair("tool1",ICON("tool1",2, 1, 1, 1)),
    make_pair("tool2",ICON("tool2",4, 0, 1, 1)),

    make_pair("fire1",ICON("fire1",0, 0, 2, 2)),
    make_pair("fire2",ICON("fire2",0, 0, 2, 5)),

};

map<string,ICON> ICON::GAME_ICON_SET(pairArray,pairArray+sizeof(pairArray)/sizeof(pairArray[0]));


ICON::ICON(string name, int x, int y, int w, int h){
    this->typeName = name;
    this->srcX = x;
    this->srcY = y;
    this->width = w;
    this->height = h;
}

ICON ICON::findICON(string type){
    map<string,ICON>::iterator kv;
    kv = ICON::GAME_ICON_SET.find(type);
    if (kv==ICON::GAME_ICON_SET.end()){

       cout<<"Error: cannot find ICON"<<endl;
       return ICON();
    }
    else{
        return kv->second;
    }
}
