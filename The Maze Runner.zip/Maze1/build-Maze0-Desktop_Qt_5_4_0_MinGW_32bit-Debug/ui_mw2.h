/********************************************************************************
** Form generated from reading UI file 'mw2.ui'
**
** Created by: Qt User Interface Compiler version 5.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MW2_H
#define UI_MW2_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>

QT_BEGIN_NAMESPACE

class Ui_MW2
{
public:

    void setupUi(QDialog *MW2)
    {
        if (MW2->objectName().isEmpty())
            MW2->setObjectName(QStringLiteral("MW2"));
        MW2->resize(1220, 750);

        retranslateUi(MW2);

        QMetaObject::connectSlotsByName(MW2);
    } // setupUi

    void retranslateUi(QDialog *MW2)
    {
        MW2->setWindowTitle(QApplication::translate("MW2", "Dialog", 0));
    } // retranslateUi

};

namespace Ui {
    class MW2: public Ui_MW2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MW2_H
