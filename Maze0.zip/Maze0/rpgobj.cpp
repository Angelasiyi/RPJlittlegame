#include "rpgobj.h"
#include <iostream>

void RPGObj::initObj(string type)
{
    //TODO 所支持的对象类型应定义为枚举
    if (type.compare("player")==0){
        this->_coverable = false;
        this->_eatable = false;
        this->_vulnerable=true;
    }
    else if(type.compare("spider")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("wall")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("Kiki")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("Newt")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("Minho")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("Teresa")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else
    {
        //TODO 应由专门的错误日志文件记录
        cout<<"invalid ICON type."<<endl;
        return;
    }

    this->_icon = ICON::findICON(type);
    QImage all;
    if(this->_icon.getTypeName()=="player"){ all.load("D:\\TileB.png"); }//TODO文件路径待定
    else if(this->_icon.getTypeName()=="spider"){ }
    else if(this->_icon.getTypeName()="wall"){ }



    this->_pic = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
}

void RPGObj::show(QPainter * pa){
    int gSize = ICON::GRID_SIZE;
    pa->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_pic);
}



