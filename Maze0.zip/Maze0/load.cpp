#include "load.h"
#include <iostream>
#include <fstream>
using namespace std;


int Load::Read(const char *filename)
{
    fstream file(filename);
    char buffer[20]={0};
    int count=0;

    if(!file.is_open())
    {
        cout << "Error opening file"<<endl;
        exit (1);
    }
    while(!file.eof())
    {
        file.getline(buffer,20);
        count++;
    }
    file.close();
    return count;
}
void Load::Save(const char *filename)
{
    fstream file(filename);

    if(!file.is_open())
    {
        cout << "Error opening file"<<endl;
        exit (1);
    }
    else
    {
        //存档 设置变量记录关数
        file << "pass.\n";

        file.close();
    }
}
