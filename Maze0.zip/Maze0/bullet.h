#ifndef BULLET_H
#define BULLET_H
#include "rpgobj.h"

class Bullet: public RPGObj
{
public:
    Bullet(){}
    ~Bullet(){}
};

#endif // BULLET_H
