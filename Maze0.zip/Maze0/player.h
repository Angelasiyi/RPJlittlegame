#ifndef PLAYER_H
#define PLAYER_H
#include "rpgobj.h"
#include "ally.h"

class Player: public Ally
{
public:
    Player(){}
    ~Player(){}
    void move(int direction, int steps=1);
        //direction =1,2,3,4 for 上下左右

};

#endif // PLAYER_H
